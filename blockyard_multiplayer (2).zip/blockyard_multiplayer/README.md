# Blockyard — single-page multiplayer platform

The entire browser experience is in **`index.html`**. It contains the Roblox-inspired home page, Discover catalogue, Create dialog, Three.js player/game, build editor, chat, and WebSocket client. `server.txt` is the Node.js WebSocket + HTTP server.

## Run locally

Requirements: Node.js 20+ and npm. Because the dependency manifest is named `package.txt` (not `package.json`), npm will not read it automatically. Install the WebSocket dependency explicitly, then run the server file from standard input:

```sh
npm install --no-save --package-lock=false ws
node --input-type=module < server.txt
```

Open <http://localhost:3000>. The server creates `./data/worlds.json` automatically. That file stores published experience titles and cube layouts. It remains saved when all players leave and survives local server restarts. Back up the `data` folder to back up your worlds.

## Create and publish a game

1. Open Blockyard and choose **Create**.
2. Enter an experience title and choose **Create & Build**.
3. The game connects to the WebSocket server and opens the editor.
4. Use **Add Cube**, select/drag, rotate, raise/lower, and delete to build.
5. Press **Publish Game**. The server writes the published title and complete cube layout to `data/worlds.json`.
6. Return home. The game appears in **Discover** with its current live player count. Other players can press **Play** to join it.

Published cube edits are saved automatically after publishing. The home page refreshes the experience list and online counts every 3.5 seconds.

## Deploy with Render

The `package.txt` file is an informational dependency manifest; npm does not automatically read `.txt` manifests. The included `render.yaml` installs `ws` explicitly and configures a paid Starter web service with a 1 GB persistent disk mounted at `/var/data`. The server stores worlds in that disk through `BLOCKYARD_DATA_DIR`.

1. Upload `index.html`, `server.txt`, `package.txt`, and `render.yaml` to a GitHub repository.
2. In Render choose **New + → Blueprint** and connect the repository, or create a Web Service manually.
3. For a manual service use build command `npm install --no-save --package-lock=false ws`, start command `node --input-type=module < server.txt`, and health check `/healthz`. Add a persistent disk mounted at `/var/data`, and set `BLOCKYARD_DATA_DIR=/var/data`.
4. Deploy and open the service URL. The WebSocket client automatically uses `wss://YOUR-SERVICE.onrender.com/ws` when served over HTTPS.

**Important storage note:** Render's free web services cannot attach persistent disks. Without persistent storage, the server's filesystem can be reset during restarts or deploys. The included Render Blueprint uses a paid Starter service with a persistent disk so published worlds survive those events. See [Render persistent disk documentation](https://render.com/docs/disks) and [Render free plan limitations](https://render.com/docs/free).

## What is synchronized

- Player positions, names, join/leave events and room player counts.
- Multiplayer chat.
- Shared cube placement, movement, rotation and deletion.
- Published experience title, creator display name, cube data and update time.
- Discover catalogue and live per-experience player counts.

## Ownership and limitations

The creator receives a private owner token saved in that browser's local storage. Other players can join and play, but only the creator's browser can edit/publish that experience. Clearing that browser's site data loses the owner token. This prototype does not yet have user accounts, moderation, backups/restore UI, server-authoritative player physics, or multi-server scaling.

## Controls

- WASD: move; Space: jump; Shift: sprint; mouse: look; V: switch first/third person.
- E: open/close build mode.
- Add Cube: place a cube on the baseplate or another cube.
- Left-drag: move selected cube; right-drag: orbit camera; wheel: zoom; middle-drag: pan.
- Arrow left/right: rotate selected cube; arrow up/down: raise/lower.
- Delete: delete selected cube; Publish Game: publish the draft.
